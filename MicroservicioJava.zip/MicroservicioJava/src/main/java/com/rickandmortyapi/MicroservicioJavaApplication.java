package com.rickandmortyapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioJavaApplication.class, args);
	}

}
