package com.rickandmortyapi.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "rickandmortyapi")
public class Rickandmortyapi {
	@Id
	@Column(name = "ID")
	@GeneratedValue
	private int id;
	@Column(name = "NOMBRE")
	private String nombre;
	@Column(name = "ESTATUS")
	private String estatus;
	@Column(name = "ESPECIE")
	private String especie;
	@Column(name = "GENERO")
	private String genero;
	@Column(name = "IMAGEN")
	private String imagen;
	@Column(name = "NUMERO_EPISODIOS")
	private String numero_episodios;
	@Column(name = "FECHA_cREACION")
	private String fecha_creacion;
	
	
	//SUPERCLASS
	public Rickandmortyapi() {
		super();
		// TODO Auto-generated constructor stub
	}
	//FIELDS
	public Rickandmortyapi(int id, String nombre, String estatus, String especie, String genero, String imagen,
			String numero_episodios, String fecha_creacion) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.estatus = estatus;
		this.especie = especie;
		this.genero = genero;
		this.imagen = imagen;
		this.numero_episodios = numero_episodios;
		this.fecha_creacion = fecha_creacion;
	}
	//GETTERS AND SETTERS
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEstatus() {
		return estatus;
	}
	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public String getImagen() {
		return imagen;
	}
	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	public String getNumero_episodios() {
		return numero_episodios;
	}
	public void setNumero_episodios(String numero_episodios) {
		this.numero_episodios = numero_episodios;
	}
	public String getFecha_creacion() {
		return fecha_creacion;
	}
	public void setFecha_creacion(String fecha_creacion) {
		this.fecha_creacion = fecha_creacion;
	}

	
}

