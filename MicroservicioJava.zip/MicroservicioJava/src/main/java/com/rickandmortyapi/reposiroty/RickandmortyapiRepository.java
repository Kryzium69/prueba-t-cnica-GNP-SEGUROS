package com.rickandmortyapi.reposiroty;

import org.springframework.data.repository.CrudRepository;

import com.rickandmortyapi.modelo.Rickandmortyapi;

public interface RickandmortyapiRepository extends CrudRepository<Rickandmortyapi, Integer> {

}
